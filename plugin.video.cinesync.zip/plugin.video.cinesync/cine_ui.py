import traceback
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urlparse import parse_qsl
import cine

__settings__ = xbmcaddon.Addon(id="plugin.video.cinesync")
cine_db = '%s%s' % ( xbmc.translatePath(xbmcaddon.Addon("plugin.video.cine").getAddonInfo('profile').decode("utf-8")), "thebas.tmp")

genero_id = {
"Accion": "4",
"Animacion": "6",
"Aventuras":"5",
"Belico":"13",
"Ciencia ficcion":"8",
"Cine negro": "16",
"Comedia": "2",
"Documental":"17",
"Drama":"3",
"Fantastico":"9",
"Infantil":"7",
"Intriga":"10",
"Musical":"15",
"Romance":"1",
"Serie de TV":"18",
"Terror":"11",
"Thriller":"12",
"Western":"14"
}

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'sinc':
            sincroniza({'silent': 'false'})
        elif params['action'] == 'config':
            __settings__.openSettings()
        elif params['action'] == 'installCine':
            install('plugin.video.cine')
        elif params['action'] == 'installUrl':
            install('script.module.urlresolver')
        elif params['action'] == 'clean':
            cine.cleanLibrary(xbmc.translatePath(__settings__.getSetting('libraryPath')))
            xbmcgui.Dialog().notification('CineSync', 'Libreria Borrada', xbmcgui.NOTIFICATION_INFO, 5000)
        elif params['action'] == 'validateLibrary':
            validateLibraryPath()
    else:
        list_categories(getmenus())

def getmenus():
    categories = []
    categories.append({'title': 'Sincronizar', 'action': 'sinc', 'folder': 'false'})
    categories.append({'title': 'Configuracion', 'action': 'config', 'folder': 'false'})
    #categories.append({'title': 'Borrar libreria', 'action': 'clean', 'folder': 'false'})
    #categories.append({'title': 'Instalar Addon Cine', 'action': 'installCine', 'folder': 'false'})
    categories.append({'title': 'Instalar urlresolver', 'action': 'installUrl', 'folder': 'false'})
    return categories

def install(param):
    hasAddon = xbmc.getCondVisibility('System.HasAddon(%s)' % param)
    if hasAddon:
        xbmcgui.Dialog().notification('CineSync', 'El addon %s ya estaba instalado' % param, xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmc.executebuiltin('xbmc.installaddon(%s)' % param, True)


def addItem(nombre, video={}, isPlayable=False):
    list_item = xbmcgui.ListItem(label=nombre)
    if len(video) > 0:
        list_item.setInfo('video', video)
    if isPlayable:
        list_item.setProperty('IsPlayable', 'true')
    return list_item


def list_categories(function_menu):
    categories = function_menu
    listing = []
    for category in categories:
        list_item = addItem(nombre='[B]%s[/B]' % (category['title']))
        url = '{0}?{1}={2}'.format(sys.argv[0], 'action', category['action'])
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(int(sys.argv[1]), listing, len(listing))
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def validateLibraryPath(confirmationMessage=True):
    path = __settings__.getSetting('libraryPath')
    saved_path = xbmc.translatePath(path)
    #xbmc.log('Path %s, saved %s' % (path, saved_path))
    if saved_path.lower().startswith("smb://"):
        msg = 'La ruta Samba no esta soportada, seleccione otra ruta para las descargas'
        xbmcgui.Dialog().notification('Cine Sync', msg, xbmcgui.NOTIFICATION_WARNING, 5000)
    if not os.path.exists(saved_path):
        try:
            os.mkdir(saved_path)
        except:
            msg = 'No existe la ruta %s y no se puede crear.\nRevisa la configuracion y selecciona una ruta con permisos de escritura' % path
            xbmcgui.Dialog().notification('Cine Sync', msg, xbmcgui.NOTIFICATION_WARNING, 5000)

    try:
        a = open('%s/test.test' % saved_path, "w")
        a.write('Test')
        a.close()
        try:
            os.remove('%s/test.test' % saved_path)
            if confirmationMessage:
                msg = 'Ruta de descargas correcta'
                xbmcgui.Dialog().notification('Cine Sync', msg, xbmcgui.NOTIFICATION_INFO, 5000)
            return True
        except:
            msg = 'No se puede borrar en la carpeta seleccionada'
            xbmcgui.Dialog().notification('Cine Sync', msg, xbmcgui.NOTIFICATION_WARNING, 5000)
    except:
        msg = 'No se puede guardar en la carpeta seleccionada'
        xbmcgui.Dialog().notification('Cine Sync', msg, xbmcgui.NOTIFICATION_WARNING, 5000)
    return False

def validateSettings():
    enabled = xbmc.translatePath(__settings__.getSetting('synchronize'))
    listing = {}
    if enabled:
        if xbmc.translatePath(__settings__.getSetting('dibujos')) == 'true':
            listing['dibujos'] = 'dibujos'
        if xbmc.translatePath(__settings__.getSetting('top')) == 'true':
            listing['top'] = 'top'
        if xbmc.translatePath(__settings__.getSetting('masvistas')) == 'true':
            listing['masvistas'] = 'masvistas'
        if xbmc.translatePath(__settings__.getSetting('ultimas')) == 'true':
            listing['ultimas'] = 'ultimas'
        if xbmc.translatePath(__settings__.getSetting('generos')) == 'true':
            listing['generos'] = genero_id[xbmc.translatePath(__settings__.getSetting('genero'))]
    return listing

def sincroniza(options):
    enabled = xbmc.translatePath(__settings__.getSetting('synchronize'))
    if enabled == 'false':
        dialog = xbmcgui.Dialog()
        dialog.notification('Cine Sync',
                            'Habilite la sincronizacion para poder realizar esta operacion',
                            xbmcgui.NOTIFICATION_INFO, 5000)
        return
    if options['silent'] == 'false':
        dialog = xbmcgui.DialogProgress()
        dialog.create('Sincronizando el Cine', "Procesando Peliculas")
        dialog.update(0, 'Esperando peliculas')
    try:
        unique = []
        faffid = []
        tmdbid = []
        titulo = []
        libraryPath = xbmc.translatePath(__settings__.getSetting('libraryPath'))
        cine.cleanLibrary(libraryPath)
        opciones = cine.pelis(validateSettings(), cine_db)
        count = 0
        added = 0
        repeted = 0
        duplicated = 0
        total_count = 0
        if len(opciones) > 0:
            total_count = opciones['total']
            repeted = 0
            for key, rows in opciones.iteritems():
                if key != 'total':
                    cine.prepare(xbmc.translatePath("%s/%s" % (libraryPath, key)))
                    for row in rows:
                        if row not in unique:
                            if row[7] in faffid and row[8] in tmdbid and row[6] in titulo:
                                duplicated = duplicated + 1
                                if (row[5] == "S" and xbmc.translatePath(__settings__.getSetting('calidad')) == "HD") or (row[5] == "" and xbmc.translatePath(__settings__.getSetting('calidad')) == "SD"):
                                    #Sobreescribo con la calidad seleccionada
                                    cine.processRow(xbmc.translatePath("%s/%s" % (libraryPath, key)), row)
                            else:
                                try:
                                    cine.processRow(xbmc.translatePath("%s/%s" % (libraryPath, key)), row)
                                except BaseException:
                                    if options['silent'] == 'false':
                                        dialog.close()
                                        xbmcgui.Dialog().notification('CineSync', 'Error al Syncronizar: problema al crear fichero',
                                                                      xbmcgui.NOTIFICATION_ERROR, 5000)
                                        return

                                unique.append(row)
                                faffid.append(row[7])
                                tmdbid.append(row[8])
                                titulo.append(row[6])
                                added = added + 1
                        else:
                            cine.imprimir('[CineSync] Skipped Cine: %s' % (str(row[0])))
                            repeted = repeted + 1
                        if options['silent'] == 'false':
                            count = count + 1
                            dialog.update(count * 100 / total_count, "%s de %s" % (str(count), str(total_count)))
        if options['silent'] == 'false':
            dialog.close()
        cine.imprimir('The process completed successfully. Completed %s, Skipped %s, Duplicated %s, Total %s' %(str(added), str(repeted), str(duplicated), str(total_count)))
    except BaseException:
        traceback.print_exc(file=sys.stdout)


if __name__ == '__main__':
    router(sys.argv[2][1:])