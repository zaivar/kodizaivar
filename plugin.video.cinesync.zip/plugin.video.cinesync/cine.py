import base64
import os
import sqlite3
import re
from unicodedata import normalize

_punct_re = re.compile(r'[\t !"#$%&\'()*\-/<=>?@\[\\\]^_`{|},.:]+')

fields = 'pelis.id,server,user,cole,peli,HD,nombre,faffid,tmdbid'

def imprimir(cadena):
    #import xbmc
    #xbmc.log(cadena)
    print cadena

def readFile(path, type = 'r'):
    r = open(str(path), type)
    r_d = r.read()
    r.close()
    return r_d

def writeFile(path, content, type = 'w'):
    w = open(str(path), type)
    w.write(content)
    w.close()

def prepareTitle(title):
    tit = slugify(title)
    return tit


def slugify(text, delim=u'_'):
    """Generates an slightly worse ASCII-only slug."""
    result = []
    for word in _punct_re.split(text.lower()):
        word = normalize('NFKD', word).encode('ascii', 'ignore')
        if word:
            result.append(word)
    return unicode(delim.join(result))

def processRow(libraryPath, row):
    tit = prepareTitle(row[6])
    format_url = "plugin://plugin.video.cine/?action=play&server=%s&user=%s&cole=%s&peli=%s&id=%s&tit=%s" % (str(row[1]), str(row[2]), str(row[3]), str(row[4]), str(row[0]), base64.b64encode(tit))
    #imprimir('[CineSync] ' + format_url)
    writeFile("%s/%s.strm" % (libraryPath, tit), format_url)

def prepare(libraryPath):
    if not os.path.exists(libraryPath):
        try:
            os.makedirs(libraryPath)
        except:
            pass

def cleanLibrary(libraryPath):
    # Borra el contenido previo.
    try:
        import shutil
        shutil.rmtree(libraryPath)
    except Exception as e:
        imprimir('[CineSync] La libreria no ha podido ser borrada')

def queryDibujos(cine_db):
    con = sqlite3.connect(cine_db)
    cur = con.cursor()
    cur.execute(
        "SELECT "+fields+" FROM pelis INNER JOIN pelgru ON pelis.id = pelgru.idpel where pelgru.idgru  IN (3, 33, 48, 52, 64, 68, 128, 180, 255, 329, 411, 461, 466, 477, 491, 574, 575, 581, 585, 624, 626, 690, 727, 771, 822, 943) order by pelis.id desc;")
    # cur.execute("SELECT distinct pelis.id, server, user, cole, peli, hd, nombre, anno, sinopsis, tmdbid, ifnull(titorig,nombre), ifnull('https://image.tmdb.org/t/p/w500'||img1,caratula), 'https://image.tmdb.org/t/p/original'||img2, size , case when pelgen.idgen = 7 THEN 'Dibujos' ELSE 'Pelicula' END dib, case when pelgen.idgen =1 THEN  'Romance' when pelgen.idgen =2 THEN  'Comedia' when pelgen.idgen =3 THEN  'Drama' when pelgen.idgen =4 THEN  'Accion' when pelgen.idgen =5 THEN  'Aventuras' when pelgen.idgen =6 THEN  'Animacion' when pelgen.idgen =7 THEN  'Dibujos' when pelgen.idgen =8 THEN  'Ciencia ficcion' when pelgen.idgen =9 THEN  'Fantastico' when pelgen.idgen =10 THEN  'Intriga' when pelgen.idgen =11 THEN  'Terror' when pelgen.idgen =12 THEN  'Thriller' when pelgen.idgen =13 THEN  'Belico' when pelgen.idgen =14 THEN  'Western' when pelgen.idgen =15 THEN  'Musical' when pelgen.idgen =16 THEN  'Cine negro' when pelgen.idgen =17 THEN  'Documental' when pelgen.idgen =18 THEN  'Serie de TV'END gen, valoracion from pelis LEFT OUTER JOIN pelgen on pelis.id = pelgen.idpel and pelis.id > " + str(count) + " order by pelis.id asc LIMIT 200")
    rows = cur.fetchall()
    con.close()
    #imprimir( '[CineSync] %s dibujos' %(str(len(rows))))
    return rows

def masVistas(cine_db):
    con = sqlite3.connect(cine_db)
    cur = con.cursor()
    cur.execute(
        "SELECT "+fields+" FROM pelis order by vta DESC LIMIT(100);")
    # cur.execute("SELECT distinct pelis.id, server, user, cole, peli, hd, nombre, anno, sinopsis, tmdbid, ifnull(titorig,nombre), ifnull('https://image.tmdb.org/t/p/w500'||img1,caratula), 'https://image.tmdb.org/t/p/original'||img2, size , case when pelgen.idgen = 7 THEN 'Dibujos' ELSE 'Pelicula' END dib, case when pelgen.idgen =1 THEN  'Romance' when pelgen.idgen =2 THEN  'Comedia' when pelgen.idgen =3 THEN  'Drama' when pelgen.idgen =4 THEN  'Accion' when pelgen.idgen =5 THEN  'Aventuras' when pelgen.idgen =6 THEN  'Animacion' when pelgen.idgen =7 THEN  'Dibujos' when pelgen.idgen =8 THEN  'Ciencia ficcion' when pelgen.idgen =9 THEN  'Fantastico' when pelgen.idgen =10 THEN  'Intriga' when pelgen.idgen =11 THEN  'Terror' when pelgen.idgen =12 THEN  'Thriller' when pelgen.idgen =13 THEN  'Belico' when pelgen.idgen =14 THEN  'Western' when pelgen.idgen =15 THEN  'Musical' when pelgen.idgen =16 THEN  'Cine negro' when pelgen.idgen =17 THEN  'Documental' when pelgen.idgen =18 THEN  'Serie de TV'END gen, valoracion from pelis LEFT OUTER JOIN pelgen on pelis.id = pelgen.idpel and pelis.id > " + str(count) + " order by pelis.id asc LIMIT 200")
    rows = cur.fetchall()
    con.close()
    #imprimir( '[CineSync] %s mas vistas' %(str(len(rows))))
    return rows

def ultimas(cine_db):
    con = sqlite3.connect(cine_db)
    cur = con.cursor()
    cur.execute(
        "SELECT "+fields+" FROM pelis where gb is not null and anno>2017 order by gb, HD LIMIT(100);")
    # cur.execute("SELECT distinct pelis.id, server, user, cole, peli, hd, nombre, anno, sinopsis, tmdbid, ifnull(titorig,nombre), ifnull('https://image.tmdb.org/t/p/w500'||img1,caratula), 'https://image.tmdb.org/t/p/original'||img2, size , case when pelgen.idgen = 7 THEN 'Dibujos' ELSE 'Pelicula' END dib, case when pelgen.idgen =1 THEN  'Romance' when pelgen.idgen =2 THEN  'Comedia' when pelgen.idgen =3 THEN  'Drama' when pelgen.idgen =4 THEN  'Accion' when pelgen.idgen =5 THEN  'Aventuras' when pelgen.idgen =6 THEN  'Animacion' when pelgen.idgen =7 THEN  'Dibujos' when pelgen.idgen =8 THEN  'Ciencia ficcion' when pelgen.idgen =9 THEN  'Fantastico' when pelgen.idgen =10 THEN  'Intriga' when pelgen.idgen =11 THEN  'Terror' when pelgen.idgen =12 THEN  'Thriller' when pelgen.idgen =13 THEN  'Belico' when pelgen.idgen =14 THEN  'Western' when pelgen.idgen =15 THEN  'Musical' when pelgen.idgen =16 THEN  'Cine negro' when pelgen.idgen =17 THEN  'Documental' when pelgen.idgen =18 THEN  'Serie de TV'END gen, valoracion from pelis LEFT OUTER JOIN pelgen on pelis.id = pelgen.idpel and pelis.id > " + str(count) + " order by pelis.id asc LIMIT 200")
    rows = cur.fetchall()
    con.close()
    #imprimir( '[CineSync] %s ultimas' %(str(len(rows))))
    return rows

def top(cine_db):
    con = sqlite3.connect(cine_db)
    cur = con.cursor()
    cur.execute(
        "SELECT "+fields+" FROM pelis where pelis.valoracion>0 and anno>2015 order by pelis.valoracion DESC, anno DESC LIMIT(100);")
    rows = cur.fetchall()
    con.close()
    #imprimir( '[CineSync] %s top' %(str(len(rows))))
    return rows

def genero(genero_id, cine_db):
    con = sqlite3.connect(cine_db)
    cur = con.cursor()
    cur.execute(
        'SELECT '+fields+' FROM pelis INNER JOIN pelgen ON pelis.ID = pelgen.idpel AND pelgen.idgen='+genero_id+';')
    rows = cur.fetchall()
    con.close()
    #imprimir( '[CineSync] %s genero' %(str(len(rows))))
    return rows

def pelis(options, cine_db):
    imprimir( '[CineSync] Recopilando pelis')
    rows = {}
    count = 0
    for key, value in options.iteritems():
        if 'dibujos' == key:
            rows['dibujos'] = queryDibujos(cine_db)
            count = count + len(rows['dibujos'])
        elif 'top' == key:
            rows['top'] = top(cine_db)
            count = count + len(rows['top'])
        elif 'masvistas' == key:
            rows['masvistas'] = masVistas(cine_db)
            count = count + len(rows['masvistas'])
        elif 'ultimas' == key:
            rows['ultimas'] = ultimas(cine_db)
            count = count + len(rows['ultimas'])
        elif 'generos' == key:
            rows['generos'] = genero(value, cine_db)
            count = count + len(rows['generos'])
        else:
            imprimir( '[CineSync] Opcion %s (no reconocida)' % (key))

    rows['total'] = count
    return rows

#if __name__ == '__main__':
#    main()