import cine_ui
import cine
import xbmcaddon

__settings__ = xbmcaddon.Addon(id="plugin.video.cinesync")

if __name__ == "__main__":
    # Se ejecuta en cada inicio
    import xbmc
    cine.imprimir('[CineSync] Cine Service Iniciado')
    enabled = xbmc.translatePath(__settings__.getSetting('synchronize'))
    dailySync = xbmc.translatePath(__settings__.getSetting('dailySync'))
    if enabled == 'true' and dailySync == 'true':
        cine.imprimir('[CineSync] Cine Service Procesando')
        cine_ui.sincroniza({'clean': 'false', 'silent': 'true'})
    cine.imprimir( '[CineSync] Cine Service Finalizado')
    timer = 24 * 60 *60
    if dailySync == 'true' and enabled == 'true':
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            cine.imprimir('[CineSync] Sincronizacion programada iniciada')
            enabled = xbmc.translatePath(__settings__.getSetting('synchronize'))
            if enabled == 'true':
                cine_ui.sincroniza({'clean': 'false', 'silent': 'true'})
            cine.imprimir('[CineSync] Sincronizacion programada finalizada')
            if monitor.waitForAbort(timer):
                break